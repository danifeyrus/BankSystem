import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
public class Users {
    Scanner in=new Scanner(System.in);
    private String name;
    private String card;
    private String cvv;
    private boolean status=true;
    private double money;
    private int id;
    private static int newid=0;
    int end=1;
    ArrayList<Users> user=new ArrayList<>();

    public Users(String name,String card, String cvv, double money)
    {
        this.status=true;
        this.id=newid++;
        this.name=name;
        this.card=card;
        this.cvv=cvv;
        this.money=money;
    }
    public Users(){

    }
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public String getCVV(){
        return cvv;
    }
    public String getCard(){
        return card;
    }
    public boolean getStatus(){
        return status;
    }
    public double getMoney() {
        return money;
    }
    public void setMoney(double money) {
        this.money=money;
    }
    public void add() {
        System.out.println("Input your name: ");
        String a = in.next();
        System.out.println("Input your card: ");
        String lcard = in.next();
        String b;
        if (lcard.length() == 16) {
            b = lcard;
            System.out.println("Input your CVV code: ");
            String lcvv = in.next();
            String c;
            if (lcvv.length() == 3) {
                c = lcvv;
                System.out.println("Input your amount of money ");
                double lmoney = in.nextDouble();
                double d;
                if (lmoney >= 0) {
                    d = lmoney;
                    user.add(new Users(a, b, c, d));
                } else {
                    System.out.println("Wrong input!");
                }
            }
            else {
                System.out.println("Invalid data");
            }
        }
        else {
            System.out.println("Invalid data");
        }

    }
    public void addmoney(){
        System.out.println("Input your card:");
        String card=in.next();
        boolean a=true;
        int id1 = -1;
        for(int i=0;i<user.size();i++)
        {
            if(user.get(i).getCard().equals(card))
            {
                a=true;
                boolean status=user.get(i).getStatus();
                id1=user.get(i).getId();
                break;
            }
            else
            {
                a=false;
            }
        }
        if(!a)
        {
            System.out.println("Card not found!");
        }
        else
        {
            if(!status)
            {
                System.out.println("Card is blocked!");
            }
            else
            {
                System.out.println("Input your CVV code: ");
                String cvv=in.next();
                boolean rightcvv=true;
                for(int i=0;i<user.size();i++)
                {
                    if(user.get(i).getCVV().equals(cvv))
                    {
                        rightcvv=true;
                        break;
                    }
                    else
                    {
                        rightcvv=false;
                    }
                }
                if(!rightcvv)
                {
                    System.out.println("Wrong CVV!");
                }
                else
                {
                    System.out.println("Input amount of money");
                    double balance=in.nextDouble();
                    double newbalance=user.get(id1).getMoney()+balance;
                    user.get(id1).setMoney(newbalance);
                    System.out.println("New balance = " + newbalance + "ТГ");
                }
            }
        }
    }
    public void pay(){
        System.out.println("Input your card:");
        String card=in.next();
        boolean a=true;
        int id1 = -1;
        for(int i=0;i<user.size();i++)
        {
            if(user.get(i).getCard().equals(card))
            {
                a=true;
                boolean status=user.get(i).getStatus();
                id1=user.get(i).getId();
                break;
            }
            else
            {
                a=false;
            }
        }
        if(!a)
        {
            System.out.println("Card not found!");
        }
        else
        {
            if(!status)
            {
                System.out.println("Card is blocked!");
            }
            else
            {
                System.out.println("Input your CVV code: ");
                String cvv=in.next();
                boolean rightcvv=true;
                for(int i=0;i<user.size();i++)
                {
                    if(user.get(i).getCVV().equals(cvv))
                    {
                        rightcvv=true;
                        break;
                    }
                    else
                    {
                        rightcvv=false;
                    }
                }
                if(!rightcvv)
                {
                    System.out.println("Wrong CVV!");
                }
                else
                {
                    if(user.get(id).getMoney()-(user.get(id).getMoney()*0.13)>=0)
                    {
                        double newbalance=user.get(id).getMoney()-(user.get(id).getMoney()*0.13);
                        user.get(id).setMoney(newbalance);
                        System.out.println("New balance is " + user.get(id).getMoney());
                    }
                }
            }
        }
    }
    public void trans() {
        int id1=-1 ,id2 = -1;
        System.out.println("Input your card: ");
        String card1 = in.next();
        System.out.println("Input second card: ");
        String card2 = in.next();
        boolean available1=true,available2=true,cvvbool=true;
        for(int i=0;i< user.size();i++)
        {
             {
                if (user.get(i).getCard().equals(card1)  )
                {
                    id1 = user.get(i).getId();
                    available1=true;
                }
                else if (user.get(i).getCard().equals(card2))
                {
                    id2=user.get(i).getId();
                    available2=true;
             }
                else {
                    available1=false;
                    available2=false;
                }
            }
        }
        if(!available1 && !available2)
        {
            System.out.println("Cards are not found");
        }
        else{
            if(user.get(id1).getStatus() && user.get(id2).getStatus())
            {
                System.out.println("Input your CVV: ");
                String CVV=in.next();
                if(user.get(id1).getCVV().equals(CVV))
                {
                    System.out.println("Input amount of money for transaction: ");
                    double transfer=in.nextDouble();
                    if(user.get(id1).getMoney()-transfer>0)
                    {
                        double newbalance1=user.get(id1).getMoney() - transfer;
                        double newbalance2=user.get(id2).getMoney() + transfer;
                        user.get(id2).setMoney(newbalance2);
                        user.get(id1).setMoney(newbalance1);
                        System.out.println("New balance for " + user.get(id1).getName() + " is: " + user.get(id1).getMoney() + "\n" +
                                "New balance for " + user.get(id2).getName() + " is: " + user.get(id2).getMoney());
                    }
                }
                else{
                    System.out.println("Wrong CVV");
                }
            }
            else {
                System.out.println("Someone's card is blocked");
            }
        }
    }
    public void block() {
        System.out.println("Input your card:");
        String card = in.next();
        int id=-1;
        boolean available=true;
        for (int i = 0; i < user.size(); i++) {
            if (user.get(i).getCard().equals(card)) {
                id= user.get(i).getId();
                available=true;
                break;
            } else {
                available=false;
            }
        }
        if(!available){
            System.out.println("Wrong card");
        }
        else{
            System.out.println("Input CVV");
            String cvv = in.next();
            if (user.get(id).getCVV().equals(cvv)) {
                user.get(id).status = false;
                System.out.println("Successfully!");
            } else {
                System.out.println("Wrong CVV");
            }
        }
    }
    public void cancel(){
        System.out.println("Input your card");
        String card=in.next();
        boolean a=true;
        for(int i=0;i<user.size();i++)
        {
            if(user.get(i).getCard().equals(card))
            {
                System.out.println("Input CVV");
                String cvv=in.next();
                if(user.get(i).getCVV().equals(cvv))
                {
                    user.remove(i);
                    System.out.println("Successfully!");
                    a=true;
                }
                else{
                    System.out.println("Wrong CVV");
                    break;
                }
            }
            else{
                a=false;
            }
        }
        if(!a){
            System.out.println("Card not found");
        }
    }
    public void printall(){
        System.out.println("Input password: ");
        String pass=in.next();
        if(Objects.equals(pass, "779377")){
            for(Users user:user){
                System.out.println("ID: " + user.getId() + ", " + "Name: " + user.getName() + ", " + "Card: " + user.getCard() + ", " + "CVV: " + user.getCVV() + ", " + "Status: " + user.getStatus() + ", " + "Money: " + user.getMoney() + " ТГ" + "\n" );
            }
        }
        else{
            System.out.println("Wrong password!");
        }
    }
    public void close(){
        end=0;
    }
    public void banksystem(){
        System.out.println("Menu: \n"
                + "1. Add new client \n" +
                "2. Add money \n" +
                "3. Pay for the order \n" +
                "4. Make a payment to another Account \n" +
                "5. Block the CC \n" +
                "6. Cancel the Account \n" +
                "7. Print all \n" +
                "8. End");

        int choice=in.nextInt();
        switch(choice){
            case 1:
                add();
                break;
            case 2:
                addmoney();
                break;
            case 3:
                pay();
                break;
            case 4:
                trans();
                break;
            case 5:
                block();
                break;
            case 6:
                cancel();
                break;
            case 7:
                printall();
                break;
            case 8:
                close();
                break;
            default:
                System.out.println("Invalid input!");
        }
    }
    public void start(){
        while(end==1){
            banksystem();
        }
    }
}

